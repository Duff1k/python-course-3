DROP TABLE IF EXISTS Faculty, Student, Course, Enrollment;

CREATE TABLE Faculty
(
id INT PRIMARY KEY,
name VARCHAR(40) UNIQUE NOT NULL,
foundation_year INT NOT NULL CHECK(foundation_year >= 1900)
);

INSERT INTO Faculty (id, name, foundation_year)
VALUES  (1, 'ИЯФИТ', 2010),
		(2, 'ЛАПЛАЗ', 2011),
        (3, 'ИФИБ', 2012),
        (4, 'ИНТЭЛ', 2013),
        (5, 'ИИКС', 2014),
        (6, 'ИФТИС', 2015);

CREATE TABLE Student
(
id INT Primary key,
full_name VARCHAR(40) NOT NULL,
birth_date DATE NOT NULL,
faculty_id INT NOT NULL,
email VARCHAR(40) UNIQUE,
foreign key (faculty_id) REFERENCES Faculty(id)
);

INSERT INTO Student (id, full_name, birth_date, faculty_id, email)
VALUES  (1, 'Иван Петров', '2003-01-08', 1, 'ipetrov@mail.ru'),
		(2, 'Петр Иванов', '2000-05-12', 2, 'ppetrov@mail.ru'),
        (3, 'Сергей Сергеев', '2001-06-29', 3, 'sserega@mail.ru'),
        (4, 'Кирилл Кириллов', '2002-08-15', 4, 'kkirillov@mail.ru'),
        (5, 'Тимур Тимуров', '2006-09-10', 5, 'ttimurov@mail.ru'),
        (6, 'Вова Вовин', '2003-07-24', 6, 'vvovin@mail.ru'),
        (7, 'Диман Диманов', '2005-03-01', 6, 'Ddimanov@mail.ru'),
        (8, 'Коля Колянов', '2003-08-14', 4, 'kolcool@mail.ru'),
        (9, 'Илья Ильин', '2004-05-23', 3, 'iliiailineia@mail.ru'),
        (10, 'Иван Иванов', '2001-10-25', 2, 'ivanchik@mail.ru');

CREATE TABLE Course
(
id INT Primary key,
name VARCHAR(40) NOT NULL,
credits INT CHECK(credits BETWEEN 1 AND 10),
faculty_id INT NOT NULL,
foreign key (faculty_id) REFERENCES Faculty(id)
);

INSERT INTO Course (id, name, credits, faculty_id)
VALUES  (1, 'Ядерка', 4, 4),
		(2, 'Лазеры', 2, 2),
        (3, 'Биология', 1, 5),
        (4, 'Электроника', 3, 3),
        (5, 'Прога', 8, 1),
        (6, 'Роботы', 9, 6),
        (7, ',бизнес', 4, 4),
        (8, 'информатика', 3, 5),
        (9, 'английский', 2, 6),
        (10, 'ОТС', 1, 2);

CREATE TABLE Enrollment 
(
id INT Primary key,
student_id INT NOT NULL,
course_id INT NOT NULL,
enroll_date DATE NOT NULL DEFAULT (CURDATE()),
foreign key (student_id) REFERENCES Student(id),
foreign key (course_id) REFERENCES Course(id)
);

INSERT INTO Enrollment (id, student_id, course_id)
VALUES  (1, 4, 4),
		(2, 2, 2),
        (3, 1, 5),
        (4, 3, 3),
        (5, 6, 1),
        (6, 9, 6),
        (7, 5, 4),
        (8, 3, 5),
        (9, 2, 6),
        (10, 8, 10),
        (11, 7, 9),
        (12, 10, 8);


