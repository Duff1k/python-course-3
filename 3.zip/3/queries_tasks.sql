-- список имен студентов с названием факультета, на котором они учатся
SELECT full_name, name
FROM Student s JOIN Faculty f ON f.id = s.faculty_id;

-- список курсов с указанием факультета, к которому они относятся
SELECT c.name courses, f.name faculties 
FROM Course c JOIN Faculty f ON c.faculty_id = f.id;

-- список студентов и курсов, на которые они зачислены
SELECT s.full_name student_name, c.name course_name, f.name faculty_name
FROM enrollment e JOIN student s ON e.student_id = s.id
				  JOIN course c  ON e.course_id = c.id
				  JOIN faculty f ON c.faculty_id = f.id
ORDER BY student_name;

-- студенты, которые учатся более чем на одном курсе
SELECT full_name student_name, COUNT(DISTINCT e.course_id) count_course
FROM Student s JOIN Enrollment e ON e.student_id = s.id
GROUP BY student_name
HAVING COUNT(DISTINCT course_id) > 1; 

-- курсы, на которых учатся более 2 студентов
SELECT name, COUNT(DISTINCT student_id) count_students
FROM Enrollment e JOIN Course c ON e.course_id = c.id
GROUP BY name
HAVING COUNT(DISTINCT student_id) > 1;